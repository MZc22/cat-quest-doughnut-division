
# Cat Quest: Doughnut Division

A multiplication and division practice game for Grade 4 students. Themed around cute cats and doughnuts!

## Hosting Instructions (GitHub Pages)

1. Go to your GitHub account.
2. Create a new repository named `cat-quest-doughnut-division`.
3. Upload the contents of this folder to the repository.
4. Go to `Settings` > `Pages`.
5. Under "Source", select `main` branch and `/ (root)`, then click Save.
6. Your game will be live at: `https://<your-username>.github.io/cat-quest-doughnut-division`

## License

Free to use and modify for educational purposes.
