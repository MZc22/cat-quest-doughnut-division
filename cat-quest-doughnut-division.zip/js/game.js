
document.getElementById("game-container").innerHTML = "<p>Game will start here soon. Meow!</p>";
